`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09.01.2026 23:21:51
// Design Name: 
// Module Name: mux_2to1_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_mux_2to1;

reg a, b, sel;
wire y;

mux_2to1 uut (
    .a(a),
    .b(b),
    .sel(sel),
    .y(y)
);

initial begin
    a = 0; b = 0; sel = 0;
    #10 a = 1;
    #10 sel = 1;
    #10 b = 1;
    #10 a = 0;
    #10 $finish;
end

endmodule




module tb_demux_1to4;

reg in;
reg [1:0] sel;
wire [3:0] y;

demux_1to4 uut (
    .in(in),
    .sel(sel),
    .y(y)
);

initial begin
    // Monitor output
    $monitor("Time=%0t | in=%b sel=%b y=%b", $time, in, sel, y);

    in = 1'b0; sel = 2'b00;
    #10 in = 1'b1; sel = 2'b00;
    #10 sel = 2'b01;
    #10 sel = 2'b10;
    #10 sel = 2'b11;

    #10 in = 1'b0;
    #10 sel = 2'b00;
    #10 $finish;
end

endmodule


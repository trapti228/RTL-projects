`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.01.2026 22:51:11
// Design Name: 
// Module Name: 4_bit_add_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_add_sub_4bit;

    reg  [3:0] A;
    reg  [3:0] B;
    reg        mode;     // 0 = Add, 1 = Sub
    wire [3:0] Result;
    wire       Carry;

    // DUT instantiation
    add_sub_4bit uut (
        .A(A),
        .B(B),
        .mode(mode),
        .Result(Result),
        .Carry(Carry)
    );

    initial begin
        $display("A  B  mode  Result  Carry");
        $monitor("%d  %d   %b      %d       %b", A, B, mode, Result, Carry);

        // ADDITION TESTS
        A = 4'd3; B = 4'd2; mode = 0; #10;   // 3 + 2 = 5
        A = 4'd7; B = 4'd4; mode = 0; #10;   // 7 + 4 = 11
        A = 4'd15; B = 4'd1; mode = 0; #10;  // Overflow

        // SUBTRACTION TESTS
        A = 4'd5; B = 4'd3; mode = 1; #10;   // 5 - 3 = 2
        A = 4'd3; B = 4'd5; mode = 1; #10;   // 3 - 5
        A = 4'd8; B = 4'd8; mode = 1; #10;   // 8 - 8 = 0

        $finish;
    end

endmodule

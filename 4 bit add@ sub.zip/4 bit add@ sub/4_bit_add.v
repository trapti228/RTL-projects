`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.01.2026 22:49:57
// Design Name: 
// Module Name: 4_bit_add
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module add_sub_4bit (
    input  [3:0] A,
    input  [3:0] B,
    input        mode,      // 0 = Add, 1 = Subtract
    output [3:0] Result,
    output       Carry
);

    wire [3:0] B_xor;
    wire [4:0] sum;

    assign B_xor = B ^ {4{mode}};   // XOR with mode
    assign sum   = A + B_xor + mode;

    assign Result = sum[3:0];
    assign Carry  = sum[4];

endmodule
`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.01.2026 23:00:24
// Design Name: 
// Module Name: 8_bit add_sub_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb_add_sub_8bit;

    reg  [7:0] A;
    reg  [7:0] B;
    reg        mode;     // 0 = Add, 1 = Sub
    wire [7:0] Result;
    wire       Carry;

    // DUT instantiation
    add_sub_8bit uut (
        .A(A),
        .B(B),
        .mode(mode),
        .Result(Result),
        .Carry(Carry)
    );

    initial begin
        $display("A   B   mode  Result  Carry");
        $monitor("%d  %d   %b      %d       %b", A, B, mode, Result, Carry);

        // ADDITION
        A = 8'd25; B = 8'd10; mode = 0; #10;
        A = 8'd100; B = 8'd50; mode = 0; #10;
        A = 8'd255; B = 8'd1; mode = 0; #10;   // Overflow

        // SUBTRACTION
        A = 8'd40; B = 8'd20; mode = 1; #10;
        A = 8'd20; B = 8'd40; mode = 1; #10;
        A = 8'd128; B = 8'd128; mode = 1; #10;

        $finish;
    end

endmodule


`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.01.2026 22:59:37
// Design Name: 
// Module Name: 8_bit_add_sub
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module add_sub_8bit (
    input  [7:0] A,
    input  [7:0] B,
    input        mode,      // 0 = Add, 1 = Subtract
    output [7:0] Result,
    output       Carry
);

    wire [7:0] B_xor;
    wire [8:0] sum;

    assign B_xor = B ^ {8{mode}};
    assign sum   = A + B_xor + mode;

    assign Result = sum[7:0];
    assign Carry  = sum[8];

endmodule
